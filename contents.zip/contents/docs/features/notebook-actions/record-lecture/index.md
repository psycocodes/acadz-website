# Recording Lectures

AcadZ allows you to record lectures and convert them into real-time transcripts. Here’s how to use this feature:

---

### Step 1: Open a Notebook
1. From the dashboard, navigate to a notebook where you want to save your lecture transcript.
2. Tap on the notebook to open it.

![Open Notebook](image-path)

---

### Step 2: Start Recording
1. Inside the notebook, tap the **Record Lecture** button.
2. Grant the app microphone permissions when prompted.

![Record Button](image-path)

---

### Step 3: Real-Time Transcription
1. As you record, the app will display a live feed of the transcript in real-time. 
2. Speak clearly for the best results.

![Live Transcription](image-path)

---

### Step 4: Save the Transcript
1. When the lecture ends, tap the **Stop Recording** button.
2. The transcript will be automatically saved to the notebook.
3. You can now access, edit, and process the transcript.

![Stop Recording](image-path)

---

You’ve successfully recorded and transcribed a lecture using AcadZ!
